self.assetsManifest = {
  "version": "OJ/uHMCr",
  "assets": [
    {
      "hash": "sha256-1K7h9KFAuXjdDHXsMhQVND18HGtPne5++wjZBzpSiOY=",
      "url": "DevTools.styles.css"
    },
    {
      "hash": "sha256-8acamWXOwn3b3oW8XQo4q/cj/T5BMx666uKPFJFTgwo=",
      "url": "_content/BlazorMonaco/jsInterop.js"
    },
    {
      "hash": "sha256-qPSbjQoelD4Xz2bZ/TU+qt7STRwp07J9MFEzAdfoWJM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/_commonjsHelpers-CT9FvmAN.js"
    },
    {
      "hash": "sha256-PraWHEApV/fz4OJ3uVK6zyGHrRZhs3e0zX5s4cWd3lo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/abap-D-t0cyap.js"
    },
    {
      "hash": "sha256-AJWuF0buVAdzi0fsn2ttz1XxMP04wmV7/Exrn+CIE5M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/apex-CcIm7xu6.js"
    },
    {
      "hash": "sha256-4T9KWW3d20yu+EIVFIZyMDw+3SKh+BC/N+n+VZXpTsk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/css.worker-cO8rX8Iy.js"
    },
    {
      "hash": "sha256-vpTP9Otelf5aGZf3PGL7yHzDsaqcmnmK6O6f8XuOA4s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/editor.worker-DM0G1eFj.js"
    },
    {
      "hash": "sha256-6CBdEb0gb0KZcVMpiqHe4mppn+eR2w+2oNqFlG24xKY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/html.worker-BruuIJkK.js"
    },
    {
      "hash": "sha256-0SzWwVnGwKLtJWGMrdM10TNyAc0cdlu9Unk40PbTFLo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/json.worker-DghZTZS7.js"
    },
    {
      "hash": "sha256-qXh5IFgd+i4qj3Izg2idIcEbXLzSRvBOQwX02jbmN5A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/ts.worker-C4E4vgbE.js"
    },
    {
      "hash": "sha256-qAdcVVuF+aVqZCyiiYbZtW94pJJQIzuazCdARYeCcOs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/azcli-BA0tQDCg.js"
    },
    {
      "hash": "sha256-kDNYGPI+Ux6niqRcRbzJHiLgqG++Tf8dOt5OTbUPt7g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/monaco.contribution.js"
    },
    {
      "hash": "sha256-Lzhjwa8fi/3Jf2OUD3/Ioj9rB0mtGCuQSmHM2w97jW0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/bat-C397hTD6.js"
    },
    {
      "hash": "sha256-x/x7UR30e5RUhswNnSKF257zfkrMGSduy9Zy/NOVn8I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/bicep-DF5aW17k.js"
    },
    {
      "hash": "sha256-P5iF/6DN3409CtqdUwFcwZeY/TRpYhrY+fvw6ClPMrI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cameligo-plsz8qhj.js"
    },
    {
      "hash": "sha256-7/7WsAC6InllMXTrU7tFEsWhth/Pess/WzxhlJ3lNFo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/clojure-Y2auQMzK.js"
    },
    {
      "hash": "sha256-MnJnJGzRHEcg1s9XbPgcvdi8lG8U7H4NKGLKhOwWmVA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/coffee-Bu45yuWE.js"
    },
    {
      "hash": "sha256-cYR0NvQnylwnilS88sWTIUxZoIjs63tyGnAnU/n8EvM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cpp-CkKPQIni.js"
    },
    {
      "hash": "sha256-7VKUKQqiSs2mFAPmAR6vcLxu9nR/AvCLBPF7eqsa0Bg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/csharp-CX28MZyh.js"
    },
    {
      "hash": "sha256-rMp9owMMdmIwQAFgMXvtYALpp7l65qXP5NL0NJWQwY0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/csp-D8uWnyxW.js"
    },
    {
      "hash": "sha256-YTn1bitTgCkCODrLniKLErnPd/aBewBp3F3Wb0Axz3E=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/css-CaeNmE3S.js"
    },
    {
      "hash": "sha256-CNrgMGXzN0aAIz0I15HZLycfW57HMQ5VI5cn+TDaMyw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cssMode-CGp6dFmI.js"
    },
    {
      "hash": "sha256-M/sO5gUOBfdwFU1KRrcTrfoaYisABi0eL31Yc/ORE80=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cypher-DVThT8BS.js"
    },
    {
      "hash": "sha256-EhOQYLzJjmb/6ayKN9UYuUcKCQ4J+2TC84ZYcyRYPsw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/dart-CmGfCvrO.js"
    },
    {
      "hash": "sha256-+2hd/SuBuSYyL+fDpQMNXQ1L1ZVqqlXC+6lKLI6MRlI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/dockerfile-CZqqYdch.js"
    },
    {
      "hash": "sha256-RdO01nkWhyrNlMFGmNBuwMnBWLglQTXpQQjns+SOs5Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ecl-30fUercY.js"
    },
    {
      "hash": "sha256-+Qo4rdi5CPAFTod0zvFcZMKmi0VDSYvZLwPZ3ZNTHw8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor.api-i0YVFWkl.js"
    },
    {
      "hash": "sha256-zmEKZHxToCB85IeQgtp2afV4k8TsQd15c9E3NDrXlg0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.css"
    },
    {
      "hash": "sha256-XDzKT3ZPVED4ol4hSQcPCVjMDTSJl8v2A5/FmxOoLZ8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.js"
    },
    {
      "hash": "sha256-CI5+wDNSZZ/EyfGt5MuBP4P0qxB8BjWGPMxK+87bxpg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/elixir-xjPaIfzF.js"
    },
    {
      "hash": "sha256-UNYfrNBM3NIY/MpQvAwhtQu+KPL4LTgjemO7uioebs0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/flow9-DqtmStfK.js"
    },
    {
      "hash": "sha256-4dLAWsypR1ZRp6Hde5E9UPUv8WmgrkKT7JN6kEtbDGw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/freemarker2-CJME-ah8.js"
    },
    {
      "hash": "sha256-YpUtTboR9hK6Q/Nvr52zr9mX13oUVid9Bwy5DZc1Zfo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/fsharp-BOMdg4U1.js"
    },
    {
      "hash": "sha256-EfcslSJeOKQnVQVtvOduXbHDS7njLbh640DceBDWJm8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/go-D_hbi-Jt.js"
    },
    {
      "hash": "sha256-So6soIXwruv0ZXNzYfIF7dMEkijf+JpfHfFDIWXQUGE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/graphql-CKUU4kLG.js"
    },
    {
      "hash": "sha256-ROaLs4W3igpfqif4F6hJtJmKYOBwadlx5kIRbjNa/VM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/handlebars-NccI6MVO.js"
    },
    {
      "hash": "sha256-UhgDxcEGVq3+kAEymVimrzivbJ/fXq0BUbPpK3lCAmw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/hcl-DTaboeZW.js"
    },
    {
      "hash": "sha256-8IZ3eqgAmYpij1eVBvwIIQel9owelvQNxhJCFfcRmqM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/html-K7M-xuod.js"
    },
    {
      "hash": "sha256-pW0kP4L7On8mzIDK6r+nHfW+opT3Niz6MA/86FgyIKo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/htmlMode-DtjCNH-N.js"
    },
    {
      "hash": "sha256-I7mu/QG4woTIh//vd6naWMbCPFDe5S5Y79PDHqC3b8w=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ini-CsNwO04R.js"
    },
    {
      "hash": "sha256-FiDigcfaE0qjRps9i2iFefDF3zqCxbBt5ccJXgPdA7g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/java-CI4ZMsH9.js"
    },
    {
      "hash": "sha256-s16DTCrR2CkieCdLITWtw1Zk0O1nHzTvBO7bI/Oa9y4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/javascript-CUpTMdAr.js"
    },
    {
      "hash": "sha256-ctgiAu4TlVT/MNVfBqhQKaWstFUhgFdUwGFugPxDFvA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/jsonMode-CJjR_ECa.js"
    },
    {
      "hash": "sha256-4ZD9KDGiTWJIOhoGdtLzpmkcShr45OCqxThHf98/k6A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/julia-BwzEvaQw.js"
    },
    {
      "hash": "sha256-7e90Obzuoc4/6AdtZKAjaCaUkVx3KiHEy+6Vh3YpLxI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/kotlin-BLeVJFaw.js"
    },
    {
      "hash": "sha256-x/Fox2UZgYZ9UpiCHQxtPoTC6+xU2ZvaLVDZ//D9/hU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/monaco.contribution.js"
    },
    {
      "hash": "sha256-0tWNtyu6tVD1B0DMhIoHKhn3UzS4ElprRhjqRtLbZ7Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/monaco.contribution.js"
    },
    {
      "hash": "sha256-ve65o9HKqvMq7Hfq91KddRkBvN31Zn6PtZmUduoDuBA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/monaco.contribution.js"
    },
    {
      "hash": "sha256-Z74sFPICBBbiKAz4sJBvyr1dzL/sWu6fvAYZYxu3P/8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/monaco.contribution.js"
    },
    {
      "hash": "sha256-MxAYVMobWE1oIbgr48tK9xvbQufWi3JomSmFJ3ave5g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/less-C0eDYdqa.js"
    },
    {
      "hash": "sha256-eI6r5QrFl6YzmfvLvUkOF57ytk3H2mIMpGPwMhFaxwg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lexon-iON-Kj97.js"
    },
    {
      "hash": "sha256-/AX15teiJD/w9V0L1EgYgrp10xPUcc4rvCAI75ybxb8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/liquid-STktYroN.js"
    },
    {
      "hash": "sha256-xHu/jjinkoUvGq6YcSXqbkh9xt31gLB0PyrDiO36hNY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.js"
    },
    {
      "hash": "sha256-MZmDi9LYTYD9N10IIaRZd+2B4r+/pZFfIIm6tSfTQ4A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lspLanguageFeatures-A02kBDb6.js"
    },
    {
      "hash": "sha256-ga564L+WTk21UYywTTWfvGZca7SW8+DrEvk8GPfIG+A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lua-DtygF91M.js"
    },
    {
      "hash": "sha256-1mI1gySLuJnuazCRLSr5i2htH+LX7yf9fZ89xdY2/aI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/m3-CsR4AuFi.js"
    },
    {
      "hash": "sha256-R9Q6NTgvvEBy1Idtr+QYjUEKSYkpiLQh7A66GUTc3zg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/markdown-C_rD0bIw.js"
    },
    {
      "hash": "sha256-HCE1QpSR7DnQ3SiTtIngxq4Y6CM8Pk7NpKKTtKWoKpY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mdx-C6mq4H94.js"
    },
    {
      "hash": "sha256-hAo5+c4C0N4ntxrc+yb+bNDhA1021BDNFbf6lU8xBYs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mips-CiYP61RB.js"
    },
    {
      "hash": "sha256-LYp5ElzwbMPhHzfh2L0sfGV/RSVZYjAaJ4E5e+chBDw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/msdax-C38-sJlp.js"
    },
    {
      "hash": "sha256-ElMw9lerUK51lrE3lIM7nqCdeoWpmJrlhhMN26Gl59k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mysql-CdtbpvbG.js"
    },
    {
      "hash": "sha256-aSVamhjru9rMFptTioDNVeHyuUDNdJXBxZFOEqP0Vuk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages-loader.js"
    },
    {
      "hash": "sha256-oyi4yoTvDUV+1vTqaLL6zr4PHrMbU7IkZpl0bAk0RC8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.de.js"
    },
    {
      "hash": "sha256-6DMbMDfiSe8NWJxjKdyVa0s1xd94PEETvdynvhhFHcQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.es.js"
    },
    {
      "hash": "sha256-GnfZW3UYCyOa/ondfRIlH9wCrbDvUFk7M03B0xbxSrQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.fr.js"
    },
    {
      "hash": "sha256-F0eIe2o8XqXmlG9XaRLEj25FFJNcQnZA23B2KBy492Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.it.js"
    },
    {
      "hash": "sha256-U7AIF8u6fnP9F70AmfhJrQFRnvmzNq2Zq87aWgDLzZ4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ja.js"
    },
    {
      "hash": "sha256-pdV1kVAgn23j+A0ZimxOtsHjKwK3TRcn78RNvpWuyHc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ko.js"
    },
    {
      "hash": "sha256-aV7S4X1GNiTGR2jcgYFs+IsH4rZmtudVU7Nt2Fz+8AM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ru.js"
    },
    {
      "hash": "sha256-DVlq5AMFMZFG6OeodMJHh2yBNiLoMyEQ0OPYhIiaol8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-cn.js"
    },
    {
      "hash": "sha256-jvvbHMdjzKpevjH485Rs6WE7jwq36oBJvsNdjj1V0p0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-tw.js"
    },
    {
      "hash": "sha256-vXLYkK4mimukFOCzUlwt3i0NM5Wc3lsysN2HNBVELQU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/objective-c-CntZFaHX.js"
    },
    {
      "hash": "sha256-aTOH21Vka9n6m5BPvV6bJJCZ2MaNJ1zzgt4wm33jZJw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pascal-r6kuqfl_.js"
    },
    {
      "hash": "sha256-F21dAGDRMxRwZ/4AQl9VZJbYlhdrjCUhn0/U2woe+9Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pascaligo-BiXoTmXh.js"
    },
    {
      "hash": "sha256-bjhSwn6GnKBlF6Z8sicJ/DaxxliFY07nDbRpoWtosrk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/perl-DABw_TcH.js"
    },
    {
      "hash": "sha256-R84+p8VQKObyzlh//c4znhjS5WAAypGtPs7s/E9ViHE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pgsql-me_jFXeX.js"
    },
    {
      "hash": "sha256-mYhgJ+F8pBhT6dSJf9KZlx76JlcdwrOzqW8OcN9o0Ag=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/php-D_kh-9LK.js"
    },
    {
      "hash": "sha256-whO3KTtKx/icXbrgsaLHwo/+5WPyvpgH/syKzrwtdTY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pla-VfZjczW0.js"
    },
    {
      "hash": "sha256-9XW9DeVjWbI1waABN0DP9K/bxQrKYlxcK+3MDghZ/fA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/postiats-BBSzz8Pk.js"
    },
    {
      "hash": "sha256-TJ5b+8R5K9co/96CPsUdTCiL7IMsJy4XW4gq3qy+Uu8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/powerquery-Dt-g_2cc.js"
    },
    {
      "hash": "sha256-GVTJJo4YVFyUDS0GdTN1cICEKZDoGavCdZXQx1uycGE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/powershell-B-7ap1zc.js"
    },
    {
      "hash": "sha256-54EMsQxiFSbJpoky3UlpHkxPSFp4HZfCIbBllpTSUJA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/protobuf-BmtuEB1A.js"
    },
    {
      "hash": "sha256-CRNC1dR+MLEM9w576IbSuD2VgLQul4WkfYZnAGQFuGc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pug-BRpRNeEb.js"
    },
    {
      "hash": "sha256-3eJ79g8xpCrzF2TGHI0x0imDKapYCY+3YsgKIRuxTf4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/python-B-Y2SC3b.js"
    },
    {
      "hash": "sha256-0n9qKTsjkl++R5J0GqyN2vx5tC1/KB42WML0nwR8puQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/qsharp-BzsFaUU9.js"
    },
    {
      "hash": "sha256-6rx3y+d5YOrOTxzpvSMBwAQq5GL5Xso/B8ts/IriROE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/r-f8dDdrp4.js"
    },
    {
      "hash": "sha256-HoifVneYO6ucb5cPGIbON01I0UUuSrPJm3umPMcdOX8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/razor-JzN5FpSg.js"
    },
    {
      "hash": "sha256-HR3aoaxqwO/9HdubX6pkCbgSh8sjv7gVvUj/qVwIOWU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/redis-fvZQY4PI.js"
    },
    {
      "hash": "sha256-sAf76VvgZUj04dT0rLiVdKqH3p7b0HNU0V8xJn9Fd/I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/redshift-45Et0LQi.js"
    },
    {
      "hash": "sha256-aGF6VGtop9DUdZHJntojZM3bqugs4pi4K2+s9woeJ8A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/restructuredtext-C7UUFKFD.js"
    },
    {
      "hash": "sha256-xWikgOSPRBu1I+FGxXfv16Y9q8ptiI0uDlEbVB89aBg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ruby-CZO8zYTz.js"
    },
    {
      "hash": "sha256-qaktruOSSgRPWW2oUzAIbBSu0xDu4vHPsLdRmIP2tYY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/rust-Bfetafyc.js"
    },
    {
      "hash": "sha256-GHM16yC5HX8MnqhCZSRvKqJxJMNPnoNiVXRAHnCAiBg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sb-3GYllVck.js"
    },
    {
      "hash": "sha256-7dT22w2f+84ZcUwm8hnvRbklnlUuf90o4elK2X4eOB0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scala-foMgrKo1.js"
    },
    {
      "hash": "sha256-f6YyVuSo1AxSSXOcaG5BAPAMCR2g6waxys98zim9KTQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scheme-CHdMtr7p.js"
    },
    {
      "hash": "sha256-dwUinYsxZD363r95KQ4QEqRuxB3NAdujQKbbJdmvp0U=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scss-C1cmLt9V.js"
    },
    {
      "hash": "sha256-yttxO5IIKrTdyiEzFJZFD0IBkJ0VDyXfcd4D1V7Xe9g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/shell-ClXCKCEW.js"
    },
    {
      "hash": "sha256-xsqgOKNIr5AjHgt4L8h9zMn5IsVQBgBy9+lduwIAHQE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/solidity-MZ6ExpPy.js"
    },
    {
      "hash": "sha256-5vhtYp83yikSZxEnB3M4wWNz0osI6ctxaCwvw5NMYh8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sophia-DWkuSsPQ.js"
    },
    {
      "hash": "sha256-TQkKgBvcgVnVolbGh4AIs/QSarQ4XmAHRJUnktWQQDI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sparql-AUGFYSyk.js"
    },
    {
      "hash": "sha256-D2vK/dJ+EE2PqcNV96nJrJpq6+3jDf/uvIdKcVIZh8Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sql-32GpJSV2.js"
    },
    {
      "hash": "sha256-ElWNC8rlYuQMcWnxqQ23wev88q1sPILMgVfmqHK7TCQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/st-CuDFIVZ_.js"
    },
    {
      "hash": "sha256-dQck8rNl53tiU0RRR1bORSvOH/HqRM9vb99FhHGcWII=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/swift-n-2HociN.js"
    },
    {
      "hash": "sha256-XTU5LZemyQZX95p3pAFTbHsC12VMTpuEzDocyPit6AI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/systemverilog-Ch4vA8Yt.js"
    },
    {
      "hash": "sha256-zyqI6g2hKfdaqKz4kVtwAtsz8GPF8Yl6hxr8tF3Lev4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/tcl-D74tq1nH.js"
    },
    {
      "hash": "sha256-FwGZHIgSeR6vxRCEGTrBqx2u8NuRvbhjjJMZECL+wfI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/tsMode-i88JHxDY.js"
    },
    {
      "hash": "sha256-0QRWN/+8H9lA6FdATMiIlO4eUYQtQa4lAzDlJ2QDnCQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/twig-C6taOxMV.js"
    },
    {
      "hash": "sha256-rFsk4PBxWzi8Ue4SaIcpvnWsdY04ItKH7jV1vmYKxI0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/typescript-4zug7YwV.js"
    },
    {
      "hash": "sha256-X5Fg9jv8IBfZTNow+93krU3AfESzc7PRI75E7uwk1zw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/typespec-D-PIh9Xw.js"
    },
    {
      "hash": "sha256-m+IopVNgitjzg/GjnAyK7WG8PWL3UH+yKTS7GhWfegg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/vb-Dyb2648j.js"
    },
    {
      "hash": "sha256-1i+FJfQH6F7yrwCAXzwWXUwDnNUjc70K7r/BFsaGX6k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/wgsl-BhLXMOR0.js"
    },
    {
      "hash": "sha256-opb8qFr5IFEXssthOF38kq4Ttdby4vGcBRf7QKs3Gb0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/workers-CbP2cVmy.js"
    },
    {
      "hash": "sha256-FeAa0jYvDWE3o4EUwqht7PXQ43olNlZj9wHgNKdAIHY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/xml-DRHZuZwg.js"
    },
    {
      "hash": "sha256-FntAl0PssVDMlLKdZVBVEUd6Z+kc2HteBw3X6fSec4o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/yaml-CkWIGXBM.js"
    },
    {
      "hash": "sha256-R8FyBgovIXHO+Iv0CZyrVhS+T30U6xRRX4tNBwjDfI8=",
      "url": "_framework/BlazorMonaco.98tzo6dc2v.wasm"
    },
    {
      "hash": "sha256-N91pyYN4k50X66SeSfEzrm0JkKpdtR+Mtvop1NTO5O8=",
      "url": "_framework/DevTools.zhvzj4la4k.wasm"
    },
    {
      "hash": "sha256-InNVlfHXAMjGIBqwwd92NJdJGoGRaEV49jHpRtNZrxg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.u4j47johqt.wasm"
    },
    {
      "hash": "sha256-5RE6DKmZC5qyWrcMQHe9om3Yrdnbwd8PwSzBAaGnRqw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.vrfxoigyud.wasm"
    },
    {
      "hash": "sha256-5G0RCpxYYATEMWRzjRgBo13ORnfchIO3v2Fu9b+/rVM=",
      "url": "_framework/Microsoft.AspNetCore.Components.cwh2jafqn4.wasm"
    },
    {
      "hash": "sha256-6E2q9fHvr9cmMb4YCOt+ngw4acFcTv4RJQixpNF1BEE=",
      "url": "_framework/Microsoft.CSharp.0q8zb7liwo.wasm"
    },
    {
      "hash": "sha256-3DH5Li3nbKgskNzRybjZBIfXSoxH/TN0wolg2KHl/YQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.w7skqr0zek.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-FU9TpGEmQwWgADUtlXFTdJIwsCDEyFtgEJacSi8iIoY=",
      "url": "_framework/Microsoft.Extensions.Configuration.jqj4k4pj3p.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-Q4ElQAxHDkCjuYL0AruUm9A7KnOrFxMIBY0KelUF1W8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.1rfo1y3yks.wasm"
    },
    {
      "hash": "sha256-DF/ymbcFNX+inXLhxorWc0PXWU7/u3c+uXIi5i8bJvI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.g5re4fc98k.wasm"
    },
    {
      "hash": "sha256-DTNxE9CKAiPWTFDFl3niOH75tY1pweWfsMzIaVbhBMI=",
      "url": "_framework/Microsoft.Extensions.Logging.r2dra2oldd.wasm"
    },
    {
      "hash": "sha256-cm6fbI6Jvm2BgJS70FB2k3qbYAzuS5nCCXg8IXj7cdA=",
      "url": "_framework/Microsoft.Extensions.Options.u4muuiav6l.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-LflsX5/lCKu5OnIeW2ybJ8WnCYONPG6qlURpO5T/y5c=",
      "url": "_framework/Microsoft.JSInterop.38vzmiamit.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-3y1thJesChYq8FDb1x+q/EF3nLkv8b/y+cAa2pI93GQ=",
      "url": "_framework/NSQLFormatter.Standard.fk4fdnwiyr.wasm"
    },
    {
      "hash": "sha256-s8KVuknfxWl1cuDvQM/OnpBfnpM1rxzvzq21S1cF36U=",
      "url": "_framework/Newtonsoft.Json.jcjjiqe038.wasm"
    },
    {
      "hash": "sha256-8Dv9+NqLRBeEaF98xCqftr7MBnb2Dl1ox/3pEiwP7b4=",
      "url": "_framework/System.Collections.4zupbwvwvq.wasm"
    },
    {
      "hash": "sha256-g20Ks7F/tYaEUBOPiWZrlqc6tA9nYYsad76WZtvV46A=",
      "url": "_framework/System.Collections.Concurrent.xnmjx2pgge.wasm"
    },
    {
      "hash": "sha256-Hri+CXSMz2w3KXmqFpmKofQZESbmIHK2I5dsIQwraYg=",
      "url": "_framework/System.Collections.Immutable.axj1ly2inx.wasm"
    },
    {
      "hash": "sha256-XlL7rF5lwK8DmL2j2rqdNuTDpQut6BmRny+dv2KL1Kw=",
      "url": "_framework/System.Collections.NonGeneric.ivvcq3e87z.wasm"
    },
    {
      "hash": "sha256-q9fmwyfl4uNAw9Mxr5lsnv3p2hGZmMoiN8xCHMjjtTQ=",
      "url": "_framework/System.Collections.Specialized.3un42x20z8.wasm"
    },
    {
      "hash": "sha256-D19RhWCtZkCpPCyXreFEQkYxavrB+yj3Wh2e6aeaKsc=",
      "url": "_framework/System.ComponentModel.Primitives.9ezv8h7qen.wasm"
    },
    {
      "hash": "sha256-qZntBLRbzxnGY3Y59CJx8a1ePN4DiYD8wZmyiRYxLI8=",
      "url": "_framework/System.ComponentModel.TypeConverter.fyktrf4i9x.wasm"
    },
    {
      "hash": "sha256-CMFU+b1d2LT8JOuvrfe5QITMKX2d44sVccWUM8Kmno0=",
      "url": "_framework/System.ComponentModel.sbhdiphx0d.wasm"
    },
    {
      "hash": "sha256-l22PLCv+cqteOyBU1EIebZyMQbuaSV8i/MN3GbbnRsk=",
      "url": "_framework/System.Console.7glofvqw8n.wasm"
    },
    {
      "hash": "sha256-7M/K0pRSG3rS/Clo4Jolb0efOTvfrVuplRBo2R7uRn0=",
      "url": "_framework/System.Data.Common.cyksncbgmd.wasm"
    },
    {
      "hash": "sha256-wWPcNNDfZ/pt5aY8se/yLmfVZcpLfb+vkseoGrc5/Do=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.5f2myvbjzl.wasm"
    },
    {
      "hash": "sha256-REUbevgxahx7+Ta3Yyl5nBwMBSeaDdtySNNRBslzdlo=",
      "url": "_framework/System.Diagnostics.TraceSource.0tzwwas62y.wasm"
    },
    {
      "hash": "sha256-+P6iv9BqBaSzIMcl/QoNjmkXV39NyvncqPXZ1Ss7398=",
      "url": "_framework/System.Drawing.8wgi7x9zvd.wasm"
    },
    {
      "hash": "sha256-R8FQ8C5HETXzl5QrDjQHcKh2e7gl/ruIbeVUmGZAJTw=",
      "url": "_framework/System.Drawing.Primitives.dr6is8pck6.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-wfgeJrIhxhAyT07f0yjfoV+iIVIqGteMg5/xdIPRiQ8=",
      "url": "_framework/System.Linq.Expressions.92jdv64jo2.wasm"
    },
    {
      "hash": "sha256-UYBqhl5GNT9816e0fScYoKb0TUj/lFtG4LAQtnBvkB8=",
      "url": "_framework/System.Linq.patwghn372.wasm"
    },
    {
      "hash": "sha256-XzA0VHViXMZP74rXNwuKKps5/YCT7xvqDlxGi0br6ok=",
      "url": "_framework/System.Memory.ni4qbvxfv6.wasm"
    },
    {
      "hash": "sha256-oIRZecH6/v7pknRrsDAg2s9w/ZJxbn9lcG2T6tMGx3A=",
      "url": "_framework/System.Net.Http.4rtfv62ryc.wasm"
    },
    {
      "hash": "sha256-GcUZS2bRpGeEZCKIDbdSt4QSQyAwEiU5RtUDWnGUaOI=",
      "url": "_framework/System.Net.Primitives.vi4gsxomfn.wasm"
    },
    {
      "hash": "sha256-j/orGPp1WbDW9TRouvgYdbl3ncK+dWY428tyqKP02e0=",
      "url": "_framework/System.ObjectModel.ln6z1u24vr.wasm"
    },
    {
      "hash": "sha256-qp/HKzrit2vu39adeVLF2R4UBG97ugJfHuKUsSzbvek=",
      "url": "_framework/System.Private.CoreLib.m82ofob3j1.wasm"
    },
    {
      "hash": "sha256-uaA4xSmveLZDnIeys5nK87rGzXtwxTH4bm/UffiOR4U=",
      "url": "_framework/System.Private.Uri.p0untnv3uc.wasm"
    },
    {
      "hash": "sha256-uxqFezximY/7QqBiz05os7l68GU473yQhP1x4lJ9GjY=",
      "url": "_framework/System.Private.Xml.Linq.9r7wqr5ket.wasm"
    },
    {
      "hash": "sha256-ovY8V8k8nur+NE3HZonRNvEUtv+4jZangwEDrdZPmuI=",
      "url": "_framework/System.Private.Xml.usxt1mg8ns.wasm"
    },
    {
      "hash": "sha256-ZZ8Yl+tzEDXUuAnCPVKMYQ3olBU48bipKbHLrw78TnI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ffvu6crlqb.wasm"
    },
    {
      "hash": "sha256-MnoV33rJKyM4ob2m+B4jDhQln2wUkc36gzI6zNKR+ps=",
      "url": "_framework/System.Reflection.Emit.Lightweight.u1f06yqgqz.wasm"
    },
    {
      "hash": "sha256-d3K/0sOH7IpBeQB9qj98KMmsPZy9QPcDIJxaT7Gw7LE=",
      "url": "_framework/System.Reflection.Primitives.nsfubnmzhb.wasm"
    },
    {
      "hash": "sha256-8dKL3KuAQ/6aymwsEOLTwMFox1n16+s10ziMSc9zlV0=",
      "url": "_framework/System.Runtime.7etpkq1itk.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-HRSi91yLdVDoBZyWsS+We3uIiS6zmgtRzLOFh8gItdw=",
      "url": "_framework/System.Runtime.InteropServices.nbg91s2y9m.wasm"
    },
    {
      "hash": "sha256-SIWolrgzpAdicHtVSaqSRoECMbKheDAY1c3a6xCwFVA=",
      "url": "_framework/System.Runtime.Numerics.4lxdurf2gs.wasm"
    },
    {
      "hash": "sha256-+YaMGRdd7ZmWXFWXUbs7wAb9AErwWb+DXX3IATt3hHU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.f6ygocimgm.wasm"
    },
    {
      "hash": "sha256-jPfC1q8DbgFXTIquSgGCsJ+Al3bChS9lXjm8hJAICJU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.467lwwghw2.wasm"
    },
    {
      "hash": "sha256-T2e9X56aOO4jjQX2VLiCAh6qSi9xtP9/xRU8zCku2uA=",
      "url": "_framework/System.Security.Cryptography.3zu22f8krm.wasm"
    },
    {
      "hash": "sha256-MFV1rWqnq/S/AtEdCoyvydacYIxU2Sajb1ETJ+dT8Bk=",
      "url": "_framework/System.Text.Encoding.Extensions.gwksaqyl68.wasm"
    },
    {
      "hash": "sha256-pq7ydT00u5UQm/avQFu31YBwr+Si5LyFKIzcQHmlJu8=",
      "url": "_framework/System.Text.Encodings.Web.i13tyue6z7.wasm"
    },
    {
      "hash": "sha256-OYDPNO4CI1Ob/eeebgSIVu7hbjkI6q/fY3pvmFYy/MQ=",
      "url": "_framework/System.Text.Json.v26w59n1pu.wasm"
    },
    {
      "hash": "sha256-nAMvDmGPh6AIV3xBv0wxAiuNyCkYgGI0Eo/+lpdjiqo=",
      "url": "_framework/System.Text.RegularExpressions.4yp1iuob7x.wasm"
    },
    {
      "hash": "sha256-/eoeqi8pIdj6qpku1wAfSipmpEIApfz/Pdm7/JlvGSw=",
      "url": "_framework/System.Threading.zkdp4s1yjq.wasm"
    },
    {
      "hash": "sha256-sndSZhomaMgZJSV8YYnGu9JTyssQJWIyipDAPAgJbwQ=",
      "url": "_framework/System.Xml.Linq.ysq4rzz6yg.wasm"
    },
    {
      "hash": "sha256-pkepRWKXWuxVlCYbRa7kuXBhefDpCQNzuk8yaZAmeBg=",
      "url": "_framework/System.Xml.ReaderWriter.azvzbgdjdb.wasm"
    },
    {
      "hash": "sha256-oKCFPxbJmB4N740vSfh6aSW9DwD8E+iInzbreWfFrs8=",
      "url": "_framework/System.Xml.XDocument.gw18htm123.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-C1zn9F1/RW4TDazqUk8iiEJyLUg2jty8urktRKl5/YY=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-49LXsMdby0iwTzWCQc3iuXacu/l2NwU4xCnIndMRkWQ=",
      "url": "_framework/dotnet.native.137dc78t3i.js"
    },
    {
      "hash": "sha256-L1Tjqww+WBV8s95fkr2SDp8C4F2CFclMQkmtEjE57u4=",
      "url": "_framework/dotnet.native.bdhl9wizrz.wasm"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Ct142n5QK6Wm9/aPiH1SQ6boJ3kW2pxxsuaBLyQpugI=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-gBuYGrcWvTKHU4Jo7+JVNc1XP54Rv4WxJ3CHjfnqz+E=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Lvne22JXwjVJcuvmZXfQsx13n5ztkzSINjI70FWqyV4=",
      "url": "js/copy-functionality.js"
    },
    {
      "hash": "sha256-VOd0jE5WWzqpQjq4miUjONKHQxWt7cbBKJe0vNIMHnc=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-+3mLshcxmGlAzzqZUPvKOG4DYz6aRUl3Aecfm4fRMuo=",
      "url": "tailwindcss.3.4.16.js"
    }
  ]
};
