self.assetsManifest = {
  "version": "9jN8GXeu",
  "assets": [
    {
      "hash": "sha256-1K7h9KFAuXjdDHXsMhQVND18HGtPne5++wjZBzpSiOY=",
      "url": "DevTools.styles.css"
    },
    {
      "hash": "sha256-+ITbtdMfLZGDlONjv3Luf5MwkD6G58PeNGSGhuHOHcg=",
      "url": "_content/BlazorMonaco/jsInterop.js"
    },
    {
      "hash": "sha256-6eDfbmswtEEcFU9d+Q/S/p06x18HGTZOJQFU46vdtAE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.de.js.map"
    },
    {
      "hash": "sha256-iuCQoWilIjMR5Usb2v3o5dFAqUelXF5yy0VnT0fU2NE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.es.js.map"
    },
    {
      "hash": "sha256-k0gFUac62cRrDBk2U07Wgcf7FZq8kHx6k1qHi7ZFBGA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.fr.js.map"
    },
    {
      "hash": "sha256-FlJh4iN0qQOXH2BK58UZs9+lxrMjUVP80L52VBGOfOk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.it.js.map"
    },
    {
      "hash": "sha256-1eMf0ejvOOS0NSpkwfoNrbB955ffklKN43xIYT5d6Ag=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.ja.js.map"
    },
    {
      "hash": "sha256-rgJn6v4f7/WrvDneAVIosbn+o/UjGID7GHEPDunGPTU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.js.map"
    },
    {
      "hash": "sha256-tmafMhBm6GT7k8ZQd3CvTG2D5H5b2g40QUSkI13YG8A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.ko.js.map"
    },
    {
      "hash": "sha256-il0t/9fXRXeXWnXOFMEsKfK2qCr68X3evZsbtYC32vg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.ru.js.map"
    },
    {
      "hash": "sha256-3SWuGOqWUIw+2BEAJVT0A+pcIyVJediHMg0MS1PkDLw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.zh-cn.js.map"
    },
    {
      "hash": "sha256-D1yWIRDrqJEjeygMoivfU3jYrHiBnei9urOS63vgMUI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/common/worker/simpleWorker.nls.zh-tw.js.map"
    },
    {
      "hash": "sha256-LTQTpHT9s2q3skutjO30rAvJV5dcy8eW3bGutqtVduc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/worker/workerMain.js.map"
    },
    {
      "hash": "sha256-0EBvifde5+nCF6mh8znQz+C9A4OHIx6mkwG970PF4YI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.js.map"
    },
    {
      "hash": "sha256-aCeqxMs3FrlEPBo01s0D/qYMEB0RaWCbAHW7QjalH18=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.de.js.map"
    },
    {
      "hash": "sha256-F8V1mQv7N03+I8xDAfl7Hx70mUVzvjrX0AWFfBYl1wI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.es.js.map"
    },
    {
      "hash": "sha256-SaruvAscW3i1Sjrpys7C+eJY38qThXB/Ug+DmXYHPnA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.fr.js.map"
    },
    {
      "hash": "sha256-TxN15oLvb+HmOMeKmANp63vkZ3r/Rf0IvYpQgtu8CyA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.it.js.map"
    },
    {
      "hash": "sha256-MCIHMQfM3jvcBhLyCKxiMJtFi0eAlGcEDV2FViWQxXQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.ja.js.map"
    },
    {
      "hash": "sha256-QPWdqXNLr65NhdTh9eX5Zo7xnrx9a3Wi4lnQqntZZR4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.js.map"
    },
    {
      "hash": "sha256-MVaE9wMB9TkFx95UrY6Bw7bfaDKW9ycSBkRNaX+jon8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.ko.js.map"
    },
    {
      "hash": "sha256-2vcZMkF/45OWWMzEL6Q2KmEVRm1mYBkQr9Igdr9JhHc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.ru.js.map"
    },
    {
      "hash": "sha256-23sVrMa0lPm0fUuzVAywdwxo9KQG6jqJHpIyueWpdto=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.zh-cn.js.map"
    },
    {
      "hash": "sha256-TzJq4gD2ITbTJnHVfJCUTdI3ECTcNQGEfnoeJV3gBiA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.nls.zh-tw.js.map"
    },
    {
      "hash": "sha256-L//o6DeYr++GlgxcEbnVxL2lMDe+zMLc0YeAHyYMen4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/loader.js.map"
    },
    {
      "hash": "sha256-YAjrSd1ospTk4UtrKS2rkYDcBjzXk0/mlpIaCVjilXs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/browser/ui/codicons/codicon/codicon.ttf"
    },
    {
      "hash": "sha256-K+IuLAo/RqQ/CaNWMDvU8IO+53X8JiPQRf22l3Z6nro=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.de.js"
    },
    {
      "hash": "sha256-UbmUUmUGPAKtxcwgHFbpNE2DbS66oz/zsSY20UA48i0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.de.min.js"
    },
    {
      "hash": "sha256-j1iUSRCjfaOkghsu9UUOOzynLh6YcD1AVttkL+1wr4k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.es.js"
    },
    {
      "hash": "sha256-EjCW6ITZXeQMHWbJm4bThrfg6zTndAJMM+LEjA9rjGA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.es.min.js"
    },
    {
      "hash": "sha256-R+e4mgXDEi2OTkkZ7SSBDgQvqdqnHP+SzVop/XrCEjQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.fr.js"
    },
    {
      "hash": "sha256-7C5WBmxwtDJszU/BZpWRqic1rAEaPfZNiHmwhyWTL8g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.fr.min.js"
    },
    {
      "hash": "sha256-CdILPOkxeWJ0XV+z/o7noPr1P2quo/zASl/Z7ghLlgo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.it.js"
    },
    {
      "hash": "sha256-UmU5kJMqC9RRhDzziNuexM+HfpqMxIoe5GD2Y8eJ5PU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.it.min.js"
    },
    {
      "hash": "sha256-FHNe3jes57lyu6FMHbvEfDlgG6gvpdszrvmw1kNLuDA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ja.js"
    },
    {
      "hash": "sha256-eOIs2g7s7nle2O3mkkhNVeFA1mkLiSzIqg0Gx1HCQbU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ja.min.js"
    },
    {
      "hash": "sha256-sWag8/V0fE2Wt5bLRejcqDSd/wEZ0Jtoh0mzlounAMs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.js"
    },
    {
      "hash": "sha256-6fSmeNT67YF+ghl2RKELdk78uQcPteK9yPMXNpgnHT8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ko.js"
    },
    {
      "hash": "sha256-WY7WRcR04USYQmoZp0usLU2n7t0u/KwTEywg9F1U+/I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ko.min.js"
    },
    {
      "hash": "sha256-KwnVsDOBUz80VW7SEkixBGRvFcANcvCrNzMiuiFPEi8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.min.js"
    },
    {
      "hash": "sha256-6NBEinV73xbICH4r1Y6yhk9d0gtMpOtCqCPel5BOTnQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ru.js"
    },
    {
      "hash": "sha256-1JDg1oFcmFudcpypGEvgUKoR7pHs1Yp8z2viGDmO4/U=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.ru.min.js"
    },
    {
      "hash": "sha256-KH0dWvJzjLuUMmUgFaN/jcauIqHFHOiIjd6hjeN2gbI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.zh-cn.js"
    },
    {
      "hash": "sha256-xTJN2nxNHad0+Q92WnJWI/ObHtLGr836vdpR46elkj8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.zh-cn.min.js"
    },
    {
      "hash": "sha256-HdRr8o1cMtYtGCbXJaOmMISXpVW9PvDkDl89S7FMOq0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.zh-tw.js"
    },
    {
      "hash": "sha256-fWsXW0USTUwqnlHN8n68MMhlmet5NR3yn6CIkwjQq3k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/common/worker/simpleWorker.nls.zh-tw.min.js"
    },
    {
      "hash": "sha256-ynTu3ivBQIB0WGSBDMe/4PVLMjzC/qjo++N/vYD73nM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/worker/workerMain.js"
    },
    {
      "hash": "sha256-IZegp5DbROWiBe4bOE+mgo24qkZHVZMStGf2U8CuOPk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/worker/workerMain.min.js"
    },
    {
      "hash": "sha256-zeFKsb1Sl6hkZ6HJ4iMLM4u8mgFUXCvWjIO/HsO8+Kw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/abap/abap.js"
    },
    {
      "hash": "sha256-+T4kWmHO/wPIF9Go2M1fus/SEb/mBc6MNJBgASPGx04=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/abap/abap.min.js"
    },
    {
      "hash": "sha256-FuGK6lbsuiItSV68/7PHrfa2s7x1hk7kc6T3rRlafy8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/apex/apex.js"
    },
    {
      "hash": "sha256-pw/JX/hG3w9Wtfs8HJS3Cx073A2G4P/PjmpcgZENiUY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/apex/apex.min.js"
    },
    {
      "hash": "sha256-rdzFKGxkzDVG0+EsX6uZRSesSCp1Xz7S/nAQO7pGkn8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/azcli/azcli.js"
    },
    {
      "hash": "sha256-94aFLbhY4SGk3gyGjvItAZfB2WZXc6NqeauiGTJ4Sa4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/azcli/azcli.min.js"
    },
    {
      "hash": "sha256-JCVVJ/U+1dMQ9FWXj7Fpk4yFwwFkGs/TNBwvdvFHHcs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bat/bat.js"
    },
    {
      "hash": "sha256-iivD5kbC0sl2Shc/mcfJpbV9+km42EAMGJtum/nwqEY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bat/bat.min.js"
    },
    {
      "hash": "sha256-lqoO0HP5chHcmXPiy1VXBx9xuzL858UBDWVUIO6GDkI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bicep/bicep.js"
    },
    {
      "hash": "sha256-FnvZ0KB7pknYirPGQjmCDrj28FtEZDX17sPBQaW7BYw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bicep/bicep.min.js"
    },
    {
      "hash": "sha256-aqJ6vIXJtWA4D9Ce81nnsd+niWSMO6YhxXILtx6dXdE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cameligo/cameligo.js"
    },
    {
      "hash": "sha256-UxdQ6b0lZd/uRZgo8N0ymmAqPx8nz0zhHZqk0P2WORM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cameligo/cameligo.min.js"
    },
    {
      "hash": "sha256-ry496vd2KtIgoIPH6R1c/BMlFWV5nWS/FkMNKvnRKAs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/clojure/clojure.js"
    },
    {
      "hash": "sha256-RR5xNG1KorpnXc2hEvv9ZDjTq9kR9w4rZ5tFXTe/4dk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/clojure/clojure.min.js"
    },
    {
      "hash": "sha256-oSnS4rIb/BgFaq7lrTjUzX3toF7VgWL7RlMqmT35vDM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/coffee/coffee.js"
    },
    {
      "hash": "sha256-LrHh5di68gJJzCo9AO9ptd8CLn00lcET6T01TszIsLA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/coffee/coffee.min.js"
    },
    {
      "hash": "sha256-7y4g1UsRE8pP6PQKXjHQtG96vQ+K0aqs2xEMEQBkhFo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cpp/cpp.js"
    },
    {
      "hash": "sha256-RG4o59CNbmjUCW6tsd01snCxbiDNlvChkpo/2gpgbco=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cpp/cpp.min.js"
    },
    {
      "hash": "sha256-LksvcrjaabNzULm5ttKTGzOx8YA73kddfgOZcXKa8V8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csharp/csharp.js"
    },
    {
      "hash": "sha256-5UcAYujYA249JZUpfYjj5gw9TG892xUQlPRc8i4X+UA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csharp/csharp.min.js"
    },
    {
      "hash": "sha256-jiB4RR7tHAa7bOl3nOmJkt6I0drNcCVlS2vy3Z60miw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csp/csp.js"
    },
    {
      "hash": "sha256-1Rg+flhv+v3LwmgY9Gc5yRPZwXNLg5V2r117KJSKMKE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csp/csp.min.js"
    },
    {
      "hash": "sha256-NeS5pYd6vDbMHjkzyG08ab+f168Lx6cXECdcIHbxu/Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/css/css.js"
    },
    {
      "hash": "sha256-0QRSNLcK1TUg/7QXpeqE7uD04xqCf3/ML9U5S64nDnE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/css/css.min.js"
    },
    {
      "hash": "sha256-Q3M+OqS4orIzcLcOIDNZbgGmP3H85A90xBO02dB8Dc0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cypher/cypher.js"
    },
    {
      "hash": "sha256-vK+wlaFjkEYiPi4XMNY7x/s3UWIk3/9Lezy7pWbloo0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cypher/cypher.min.js"
    },
    {
      "hash": "sha256-2Zs3H0UYQLbT3Vm2sDsW4EkDB3q35P0BYKaXXip2acU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dart/dart.js"
    },
    {
      "hash": "sha256-Rsf4kwRIxikCQCdTY6w3+rJF1xz6+xPn3nbdYWY9os8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dart/dart.min.js"
    },
    {
      "hash": "sha256-0Rfx65G7HX5AobVdnCqBBaPnlOTN1vOTKyFeV0ZCa4o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dockerfile/dockerfile.js"
    },
    {
      "hash": "sha256-xE4SnpZCeXV5sNfTD+LUILWwJQ3YaiRy5qtiOYurUVc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dockerfile/dockerfile.min.js"
    },
    {
      "hash": "sha256-yPy3RQwsq23IVX+H1fI7C2kvSgj7dfH7XHmI+pSdzsg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ecl/ecl.js"
    },
    {
      "hash": "sha256-T+JUWv5Ohq2Z0bT0KM+WO+mipR0wKmOc6KBazgKQoKM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ecl/ecl.min.js"
    },
    {
      "hash": "sha256-93fMLNG7PzlE/UBf/uBuazhHLGbGbAxmA0WyNIRZfcE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/elixir/elixir.js"
    },
    {
      "hash": "sha256-KMq8Qh5CCXSPvcYPuLvTvzTLyvpCkaJ6CxKBbYdNDTI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/elixir/elixir.min.js"
    },
    {
      "hash": "sha256-1RnCfbIBgB7aBrZR/rAsWjwZpDZrPIYAh/SNTkCtbYM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/flow9/flow9.js"
    },
    {
      "hash": "sha256-5TY/LJFq/yaXR5XLfVfLU41izP1Wp3aM4Ab//9uo7Rk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/flow9/flow9.min.js"
    },
    {
      "hash": "sha256-qX+j5ck8xEe/4TJ5+KohpqyrFxqSfYI+WBRnWArEx/A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/freemarker2/freemarker2.js"
    },
    {
      "hash": "sha256-2OGgeKqAf1allYAX1QXV66AzG4PCM+IALwQZ96OwT/0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/freemarker2/freemarker2.min.js"
    },
    {
      "hash": "sha256-4ILBxncKoNPs0Gwd3O1iWbPUVoFnqyqpj+01CLaiCzo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/fsharp/fsharp.js"
    },
    {
      "hash": "sha256-+zB99crII7SsOpzjsr/LhpTOFG1kOR9Eb1kzkvd6jEs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/fsharp/fsharp.min.js"
    },
    {
      "hash": "sha256-hdSptAACSYr5Fcx/ZWFWrH2BK4qSlcEEbcJwkPia82g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/go/go.js"
    },
    {
      "hash": "sha256-MY05rWlQIagO/A30+lII/mL/h6nQs4zZLzISdmDePaY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/go/go.min.js"
    },
    {
      "hash": "sha256-THZloq/yAjlqRhIhEcMQISHf47ns18j8exRSboa4A1Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/graphql/graphql.js"
    },
    {
      "hash": "sha256-eF6zu6Bx6oGmhqQI+3IEbpiYEa8DEJSOxHaVcg0lZIs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/graphql/graphql.min.js"
    },
    {
      "hash": "sha256-8106S2IPyd4qS+f/dhEmJE4ujBStjEnDuDHz30gTRD0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/handlebars/handlebars.js"
    },
    {
      "hash": "sha256-dPIjxsYAMrQP6rBWgNu7dS8f4N2JJJIXCiLjsarpKTY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/handlebars/handlebars.min.js"
    },
    {
      "hash": "sha256-TMWsmBy16EjEWt+88k+JxOsIphSGgacJ4PN0sEvTDwI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/hcl/hcl.js"
    },
    {
      "hash": "sha256-Pguh06L/v517EvMXCHoLo2jHxokCwI3b2cuN4829gr0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/hcl/hcl.min.js"
    },
    {
      "hash": "sha256-CnW5av0lsmkEVeWTzZtC6jxyp7LtkaM4CF99wUEtJ0o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/html/html.js"
    },
    {
      "hash": "sha256-bCN0XECkmfQOSe6zO7WK/YJR4AsEpKqr41D6ePUb7KU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/html/html.min.js"
    },
    {
      "hash": "sha256-cif1NNFoMoMbCA4jabdKkwNQjonefPKAetK/GiJy5QI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ini/ini.js"
    },
    {
      "hash": "sha256-LBBQudCGB63g9QGs6IVv+wE3CVt5bQrhyBPTe4FlSgI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ini/ini.min.js"
    },
    {
      "hash": "sha256-dAcpAD2ExdugGh/JQSoqyDS4xG+RhRw8wmjM6Fu5LXg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/java/java.js"
    },
    {
      "hash": "sha256-R0cfyvyQPnQzen7J53ZQdAfdsO1Fjj6oJmmoEpbFpFQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/java/java.min.js"
    },
    {
      "hash": "sha256-0vAYgjWADndYrhB3UiK1NPXnziV2Get7cIdszEGuoko=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/javascript/javascript.js"
    },
    {
      "hash": "sha256-bM+iQsCiXV7x0aHTt589MgiXFxGHipvjRlawaXX2LF0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/javascript/javascript.min.js"
    },
    {
      "hash": "sha256-smU3J+Do6/CitPL0vKE57PyHgqo1aApTYISURhrPU4g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/julia/julia.js"
    },
    {
      "hash": "sha256-BpLtcpZgoquZHShHoOlSuiizVJrwmZujTCVrS6lz7kc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/julia/julia.min.js"
    },
    {
      "hash": "sha256-5JrYm0y1y0wbwv5Kr19o1wZ/iQe4jkriGehTSAkZuG8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/kotlin/kotlin.js"
    },
    {
      "hash": "sha256-TuLx1nspNLMGv7kTDIo57k+L0kRCb7HxUTtvrCZEBXU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/kotlin/kotlin.min.js"
    },
    {
      "hash": "sha256-Jf34gxonA9RWofZyDQzoI7qKupE975Hc+jnpmu0/AUw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/less/less.js"
    },
    {
      "hash": "sha256-LBeq3zXAkROB6KdErjx95Dse5o5noWV+gyA1Fe2U0oc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/less/less.min.js"
    },
    {
      "hash": "sha256-iMKs7Oets4vc9ak6RjIiWuVIyos3MwJ/I9T2h3j/pOs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lexon/lexon.js"
    },
    {
      "hash": "sha256-TnlfLyq11ZmCNe3DamazKHrc/QJIqHTyruhutJ7m5Qo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lexon/lexon.min.js"
    },
    {
      "hash": "sha256-ECRmQBNqzH2uBsphulyKnNLqCASTajCQ462Ve0sc6KA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/liquid/liquid.js"
    },
    {
      "hash": "sha256-OmfnLy6CENNFZ2BklMW3eBRGVnAt5T0Nz6VjYNg7fEM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/liquid/liquid.min.js"
    },
    {
      "hash": "sha256-eOz3p5Vknnif6vptOzqLwFEgsVZg5hnHoArQyB7UBXY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lua/lua.js"
    },
    {
      "hash": "sha256-NNZGzJX4xlqBMk8TQCd1XCcex/2wUeiIju+3Oav7xuA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lua/lua.min.js"
    },
    {
      "hash": "sha256-sKtYX7WtGw1kNLgm8/SwAZlJFnm6JcAhfOhO+xushLg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/m3/m3.js"
    },
    {
      "hash": "sha256-kClu54F64ZiU1DbJdOztQQZTlPgUnV777oLPPEsEna0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/m3/m3.min.js"
    },
    {
      "hash": "sha256-KX0aPGnKhulKibTTAfbTHEJy1iqMhPFnjoZRf2qBEpY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/markdown/markdown.js"
    },
    {
      "hash": "sha256-KBWXGjH7Ce8xX0XzAJRRnzI5NKIdC7fQjpXAbHLywKg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/markdown/markdown.min.js"
    },
    {
      "hash": "sha256-roDpMIrUwCPpzuwZHkQGrE6uSK0fcoWlumVCJHVl14o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mdx/mdx.js"
    },
    {
      "hash": "sha256-ZXY1PpbqfYVA0IyOgTqhBeZWZlhqRYli3mao/bCSjuE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mdx/mdx.min.js"
    },
    {
      "hash": "sha256-v3dU8izRv8bTT2Pi1WtYn+3PqwQB8BxlNEsVZa6cuHo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mips/mips.js"
    },
    {
      "hash": "sha256-yVowx5dKDGWKLDGh0ONJjFLmjykHcF6M6H+wL81kBHM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mips/mips.min.js"
    },
    {
      "hash": "sha256-Rfj+Fo8do9XRa5vAp1IFFt5FDBCZOGLpo5IOV5Wq4rg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/msdax/msdax.js"
    },
    {
      "hash": "sha256-LXVlUFznbKjmqCJcwwO08GHpe3T69m2fZrjmUAgoYKA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/msdax/msdax.min.js"
    },
    {
      "hash": "sha256-50rAcQuvkrYjU9JD/OWKBi15IzLhxPxlIwpYCPSXCiU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mysql/mysql.js"
    },
    {
      "hash": "sha256-PE5cRmwT7xkUFTXpXMx2+qvNCqmFN4snayt8iTDgtkg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mysql/mysql.min.js"
    },
    {
      "hash": "sha256-AfvH18SJwrVpRpAWb42bXuPMONuLdLCGFzfx0mxir5g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/objective-c/objective-c.js"
    },
    {
      "hash": "sha256-Qg1HITcAT3wn16rNGVebNbO6dqkIf+gYXd6gMwO+IKU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/objective-c/objective-c.min.js"
    },
    {
      "hash": "sha256-HkUPfZqXI/YuzBSEBq0m2uU7N8g3juofLYD/t30CR1k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascal/pascal.js"
    },
    {
      "hash": "sha256-o+6GvcLtiIXkt0w93p/nd7t+jFK9EQWoGR5P7DEHsFk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascal/pascal.min.js"
    },
    {
      "hash": "sha256-P7vhIVQcQ4s/RetC/3fluno7FuT3GgqETieAoPsoAn8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascaligo/pascaligo.js"
    },
    {
      "hash": "sha256-RmT0Y5eJxAz2avz45DsY/6zYsKZRS+NIglwuAxB1Wpc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascaligo/pascaligo.min.js"
    },
    {
      "hash": "sha256-FkKlfTAIOcxR2AztUdbz9fq1HmvqTYy/9HY3s7RgsRw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/perl/perl.js"
    },
    {
      "hash": "sha256-mfSYOf8zJjyQhxD/jvaWcVKtXjiMSHwLrxBtpGAYO2M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/perl/perl.min.js"
    },
    {
      "hash": "sha256-PpC6IUv8pt3KeCssA7XFiJ00F1EuK4M1CxMq8CVwIeI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pgsql/pgsql.js"
    },
    {
      "hash": "sha256-poWK5XY8t547d9lW3+KAg0wQdbMu+qmjoJLeulR5SgE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pgsql/pgsql.min.js"
    },
    {
      "hash": "sha256-qNXHYF/XHikiF4OmKPlmwZ/7XDLXuNWvZxkf4IvbC/U=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/php/php.js"
    },
    {
      "hash": "sha256-bShj6DOd3dnq3qUjJiWHJsbYYdSK23m4wK4U1nOV6CU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/php/php.min.js"
    },
    {
      "hash": "sha256-xhDReuDg37GjyiyAGU+G+C6d6wqPZCcFtZsOBMGw41Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pla/pla.js"
    },
    {
      "hash": "sha256-pLhuL6KAO3SMo8mn4oDj7O13dXpn65C/TOCC3Q+slcM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pla/pla.min.js"
    },
    {
      "hash": "sha256-6t0IK3g/7DchdvvRBtKGRIY3jpMDgR2GOrJJgEilDFw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/postiats/postiats.js"
    },
    {
      "hash": "sha256-mptYA8e0VbLZEa+EB64779XTpK5I2OcjfOZqNC/OLWA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/postiats/postiats.min.js"
    },
    {
      "hash": "sha256-zplOtoAZcJfxzcyjEuHflECQy6UwqUwdITP5GObCI/s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powerquery/powerquery.js"
    },
    {
      "hash": "sha256-l2Vu9w3NCZ1+vAKJt5HSyMi91/k7W7maDtmajYmJzm4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powerquery/powerquery.min.js"
    },
    {
      "hash": "sha256-SzaJvsPQfC+w/X0uZJBSJRQUwmc9qVk9QKFk/i5Z9SE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powershell/powershell.js"
    },
    {
      "hash": "sha256-9bQzEmSkdRVLNBqY69j/qVGQ3t9sQogxKJLEhdniSUI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powershell/powershell.min.js"
    },
    {
      "hash": "sha256-QqvXkebmfR/78IPuDRjyasYuUjPsWaMgvpH+yeI+kwA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/protobuf/protobuf.js"
    },
    {
      "hash": "sha256-yEHe6CLRks74sXHOVyRFQGJm6H6FSfHuda1flCtAT1A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/protobuf/protobuf.min.js"
    },
    {
      "hash": "sha256-Jg+BTTX7ZU2WKKySIk9PFRJCTWw6GQ8ziRtL8fBbFVY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pug/pug.js"
    },
    {
      "hash": "sha256-tfRYwJBeS1IOUcXsgRuaeRD4IsmKFZW9vn6cUFruemo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pug/pug.min.js"
    },
    {
      "hash": "sha256-B4Ih3s60UidQEnRUNw2Q4a6YkLESaxdufCkpCLWdsd4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/python/python.js"
    },
    {
      "hash": "sha256-C4e120rfoNa2eFsxyW/HVImkZpFExnnkxBRjOPHod6Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/python/python.min.js"
    },
    {
      "hash": "sha256-oVNiORaSRmsgrB561mAxME9MzAZhBafe4/WRlGlvwZ0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/qsharp/qsharp.js"
    },
    {
      "hash": "sha256-hu5GltqcjeaZ8uxm1v/BTQf1mRFZVg+1lJGRAgc+v7c=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/qsharp/qsharp.min.js"
    },
    {
      "hash": "sha256-Wk3RAMYK2wQMAV1eRvmzFGpBkLnBeeYzu/btZfeWDkU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/r/r.js"
    },
    {
      "hash": "sha256-qxYtk/YAxRX6bmRAzmtvODGExZnnTGsKOCu0PpiNZZI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/r/r.min.js"
    },
    {
      "hash": "sha256-NLmMz+XEBJsQh7XjtRossdgKS0eBcMjUsapBK9Vegwk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/razor/razor.js"
    },
    {
      "hash": "sha256-BIcH2PSa+qjOJ6SgBBsMyV/ywN1Q3WGAuA7B7CqDDmw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/razor/razor.min.js"
    },
    {
      "hash": "sha256-EN1MBubNvOzXcm3ACH6wjjGDmwLD8NhJPuCEIQDih/k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redis/redis.js"
    },
    {
      "hash": "sha256-p4CJuQti3GuhT6uup47o79ZXfLkddZhMwDKxY077CS8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redis/redis.min.js"
    },
    {
      "hash": "sha256-V03FEcz7mJPAYrsl9mLrRpfp6yp88LGCYn2X47EIC9g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redshift/redshift.js"
    },
    {
      "hash": "sha256-8mYe0QaH6WQKGf6/sTS1zxrcCz6hndS7Sfmx3rqGXzE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redshift/redshift.min.js"
    },
    {
      "hash": "sha256-a4zzPLxbBVAEOia0fEgTc5P8d4/piu+4REdRO6g4hj8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/restructuredtext/restructuredtext.js"
    },
    {
      "hash": "sha256-RJ8kJC80s8atDJJat9InM/aPb2+4KMVp6QC0nCQlfao=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/restructuredtext/restructuredtext.min.js"
    },
    {
      "hash": "sha256-1xoQ2AhsYH9szbE0uqo6fIgkPFY0eAYeant0YCCCAQ4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ruby/ruby.js"
    },
    {
      "hash": "sha256-7e0wEYLgPouk1R2trsn+00i15Jl2o9DZbGNuTg1Ke5A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ruby/ruby.min.js"
    },
    {
      "hash": "sha256-IVkYh8LgbWGCARbZIsdvjjH+iBhSP7Fy/aHWEQvJXHY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/rust/rust.js"
    },
    {
      "hash": "sha256-ji2H7bmW1Vzq4sUK3Ocw9/y+55jpvzH77O9mWAtH5t8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/rust/rust.min.js"
    },
    {
      "hash": "sha256-NO7WudBBirzMepYqlHNJFv6f4HTOpRWDHtNqj0uZKX8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sb/sb.js"
    },
    {
      "hash": "sha256-+bxJMza+rBY4lv0PGXD3VUifawzN0f7/iP+RkBNSEC0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sb/sb.min.js"
    },
    {
      "hash": "sha256-R9QJ9KZRFpEkmCf+VQdN//xrhxoNmjmck6mIZXlg2TY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scala/scala.js"
    },
    {
      "hash": "sha256-ubHILxXZaPJwyvZiVqoVwYFkWwcbx/4Uu/f2Fy9SCgg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scala/scala.min.js"
    },
    {
      "hash": "sha256-6+1hBMuYh2sK1OAnjCRKf0kexMMm6qnrpL628tg1C4c=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scheme/scheme.js"
    },
    {
      "hash": "sha256-cBBtJ2LaUEQDlYcQCOFGBbIxgAbSaXcoGagJx8vv/rM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scheme/scheme.min.js"
    },
    {
      "hash": "sha256-HiwvlOkGeAQljyboWCrP0cTGT1CNRNsrMX+poTAFfoM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scss/scss.js"
    },
    {
      "hash": "sha256-7gIx0AoYJ6VlcNCz76BX13phj2XlGph3cUCsn8Sf7wg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scss/scss.min.js"
    },
    {
      "hash": "sha256-lFGiilcRQhfprvLXhldQrRC+ff8hbM1QIg9O3RAIONI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/shell/shell.js"
    },
    {
      "hash": "sha256-+Aprl8W6Yvxl19bb6TrmC7Dgz118VP1KOh/FYWwKwzQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/shell/shell.min.js"
    },
    {
      "hash": "sha256-yBLMJe8rj3Y93zApFtoOKpmCf3IikM4dCeb/w6GcdF4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/solidity/solidity.js"
    },
    {
      "hash": "sha256-w68unfLT6hzy0TD19+zKXvXgOCEemz3eXlQz1PUeT0s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/solidity/solidity.min.js"
    },
    {
      "hash": "sha256-k4LFuyqP5pq7++cIvLDjYxhEcCShXIpBkiTa5tHucME=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sophia/sophia.js"
    },
    {
      "hash": "sha256-8AZ01NhXFWAKYm4TE/OoCqiimIyMtVdd4Z1EOoVonQw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sophia/sophia.min.js"
    },
    {
      "hash": "sha256-aSIOqDSz/hkqhJz481JgU0yCvQ7/kG8s/IAng0uXh6M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sparql/sparql.js"
    },
    {
      "hash": "sha256-qAHt5jz6YjCjn1DGMQRd3kde9YWWFS5EOpq/T7pX7Ic=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sparql/sparql.min.js"
    },
    {
      "hash": "sha256-B6ok6F2EsyZXCKTp1SFduNPs/Cu51BXFAWsVbRsa7vU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sql/sql.js"
    },
    {
      "hash": "sha256-n+SQuV/ty62FqGwp2dNXou/50mKyLyJlh5MX+A0M1MY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sql/sql.min.js"
    },
    {
      "hash": "sha256-/2iUA3tnmpBJ0qv3hy/1BwKABn6Go2aAgp00it+wXIE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/st/st.js"
    },
    {
      "hash": "sha256-TQ8X2wkHYRabm37fcJhKW1EPVDUvEsxSa84GFTa4X8M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/st/st.min.js"
    },
    {
      "hash": "sha256-cYSnhVk+yKBJhTKkeMKDCDN/+Ze3CRK7dAG/Kkoyp6o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/swift/swift.js"
    },
    {
      "hash": "sha256-jZIpq4KHIu2NKxMsKA4ZIE+M1EQi12PCmVzuBSArJDY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/swift/swift.min.js"
    },
    {
      "hash": "sha256-9RwOJny2ZdY4hWOwq4IEkd3KIsq849THaT6u9VLNC+o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/systemverilog/systemverilog.js"
    },
    {
      "hash": "sha256-YlKz9vHdgfh+scJVCJNKv7sP9Yfiezjx6aeEZjn10vM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/systemverilog/systemverilog.min.js"
    },
    {
      "hash": "sha256-BbNyUmHRK1pKKhuYoNKWTNPE0WkWw2OPEDOqffW764A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/tcl/tcl.js"
    },
    {
      "hash": "sha256-ClchEv9Ol3GVhy8d8b+vQTN2CnM60+R7f4W7xsW1kzQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/tcl/tcl.min.js"
    },
    {
      "hash": "sha256-fkf9qhdVTA6m34sNZoH5kusIbGhmf9D/vuXRCMP/vyg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/twig/twig.js"
    },
    {
      "hash": "sha256-hEFYtyFLvOPLx179NVCOKdidZxja1jVX2b3Sekkn5XQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/twig/twig.min.js"
    },
    {
      "hash": "sha256-IveFidmr8Sf/Z+45xgQNdOOPbH3+zH9nMqvu90j1YPM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typescript/typescript.js"
    },
    {
      "hash": "sha256-YHyZmTl6Ul9ZK8AHDCqtMAXiLAWqrO7Ax5YqcU1ZJio=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typescript/typescript.min.js"
    },
    {
      "hash": "sha256-UsoKejaRKe/tbLB+Rd3C5rSOxPSPJZKmxuv0Xi0IRMs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/vb/vb.js"
    },
    {
      "hash": "sha256-4+SibikyGOUDarmouutz2j/mIfcwe1fIoGxmTdxNWo4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/vb/vb.min.js"
    },
    {
      "hash": "sha256-EZmX7eFp5JAPO0EOgsEjBLlzvtu4ZYmypIjP9QxtIaM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/wgsl/wgsl.js"
    },
    {
      "hash": "sha256-xnGcA0+jClXDlbbjXhtw91OvnW78Smd8qcItQwPaMbM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/wgsl/wgsl.min.js"
    },
    {
      "hash": "sha256-5tf43o/H9nYvblwFDRZyFx3bVGCKzLAyOFRzPaWNVaA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/xml/xml.js"
    },
    {
      "hash": "sha256-x/AoisVk9y6G7IFxQFsVkSyY3A+jk1+Jxfc8YkqkMio=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/xml/xml.min.js"
    },
    {
      "hash": "sha256-gal2MGb17UvtBOrELSZkYzfFuT86HB9GIgAo/NDErA8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/yaml/yaml.js"
    },
    {
      "hash": "sha256-BvkPYc2mX65ZZuO1m91ojLajutiMu4BreSAgUfbE9sw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/yaml/yaml.min.js"
    },
    {
      "hash": "sha256-IQHSTDfvh3LNo/WdbZnpKGDegJaWwpP/FMbavZROFhw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.css"
    },
    {
      "hash": "sha256-HXp6anbHO+2ojYlpTtrxCSN+I9ODqiI21u1h60EEHhA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.js"
    },
    {
      "hash": "sha256-Bej0cLG0pE7VMmjWculjEj12HU08NqnbgmuKnlNC4Xw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.min.css"
    },
    {
      "hash": "sha256-TSJMnIxZBYiHfbGeRtpd929vtqp/3DEO1AVLamim2Q0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.min.js"
    },
    {
      "hash": "sha256-Q5ycOaqY7r2xDMdaxhxhXb8zTZG51GJ8wjbztYWVJuw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.de.js"
    },
    {
      "hash": "sha256-HwdSaiueP2VB5nAeNEabazQAyxh8+YE3IDVUo2yCF9M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.de.min.js"
    },
    {
      "hash": "sha256-U8jn+Iq+kGLJt0Dr9T/AwAUAoaFrswj80eOnww2zpNk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.es.js"
    },
    {
      "hash": "sha256-CNjMQcmuFEefLELHFZqY2kSZMnKzH+ACitxeLbO+Bqs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.es.min.js"
    },
    {
      "hash": "sha256-azeQsu/k97/TqzCtUZtUxx9j8IF8MGaIjQwtzQVodDk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.fr.js"
    },
    {
      "hash": "sha256-WBqXlC/dFzH/O6lcwsFrD7WqM/KVCVsM7whAO9bciN4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.fr.min.js"
    },
    {
      "hash": "sha256-NtjPZcwsQjw6voYOfIsfsa1Vo7pBNdPlJGcceDEyQno=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.it.js"
    },
    {
      "hash": "sha256-4DXL17qdAXgRqHkIBbrwsWgjrmwDsTy2u16E3Tu3juY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.it.min.js"
    },
    {
      "hash": "sha256-rq4zNxXXbxK0tY/ySurjpQGUjWS1Te7WPDGlkIIDrO8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ja.js"
    },
    {
      "hash": "sha256-WlGYhU7PjvvqVQc4yYXsYkz44QXgoleszUoi8wXyyZE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ja.min.js"
    },
    {
      "hash": "sha256-fThea2K4WaqevDoVxMVekBtN+H8P0/LfO7lGtYNpxZg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.js"
    },
    {
      "hash": "sha256-Eal4reEEJ/9qzOxoF5DXfYLCbWeQYQWtC9zo28S7U+M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ko.js"
    },
    {
      "hash": "sha256-82JdOqPAg2ycttkfuOmHiRMosH+xkDm8tnm6FGvCBA0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ko.min.js"
    },
    {
      "hash": "sha256-QzPM3XngfM0pp5km10R3HuZLQSIGpifgSyPOgQb4m6Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.min.js"
    },
    {
      "hash": "sha256-VIUg03qMr3il1GRBF+uzDfJHUJHr6aENuFoEfZFSCMU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ru.js"
    },
    {
      "hash": "sha256-UT3kSjeCIAQt73BdbcdmX5Thd4JTNHGD5ks6d0pH7Dw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.ru.min.js"
    },
    {
      "hash": "sha256-LOZRkq0nK4kurEajzOeZZfkkZ3gZhn4OqK9kzieEpak=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.zh-cn.js"
    },
    {
      "hash": "sha256-hEKSNf6C5gGTRBy5tTwbfgVdPchXZTQ0rVye7IKdIaM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.zh-cn.min.js"
    },
    {
      "hash": "sha256-zvyHJokF1x6jXiRlR0Ke8wGg/tAvwdTU3SK8/IaNioU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.zh-tw.js"
    },
    {
      "hash": "sha256-VaVwGlAWDKzSh+5RxZeYl6K4XgUf4SzO5TM6eh3rKlE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.nls.zh-tw.min.js"
    },
    {
      "hash": "sha256-GSxxF/nfkSZLPQUbZu3cjZUQnBMkUyUN6jgKrXIKb8k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssMode.js"
    },
    {
      "hash": "sha256-7wUedPYaVOCaDX5ZugPVS+aM9lfTbOHjg0JKjQ2B1SM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssMode.min.js"
    },
    {
      "hash": "sha256-a7zOjkswPJ0jygSm5uIN3RpqHxkJ1Z876MBRKV4hUPg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssWorker.js"
    },
    {
      "hash": "sha256-03IKI3sw9Y8q6rhkJeOR51bxkgmuN1OFjFm16/ERDXQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssWorker.min.js"
    },
    {
      "hash": "sha256-7tIhRMn66m2R77s27hCtXPh7oiNbs26g8PUch4OIiLM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlMode.js"
    },
    {
      "hash": "sha256-AjzsogjGu+v0MJU/LvK6YqY9u215ym8655Z+2wbfObY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlMode.min.js"
    },
    {
      "hash": "sha256-FcNVJD51iw7fr68oup3k5uFHt+Ft6tI3SVSENqUUUzQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlWorker.js"
    },
    {
      "hash": "sha256-MUU2DKtap/cMwkp8+HhRClGSWWGQ5wdeZ2QyKQ/1b24=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlWorker.min.js"
    },
    {
      "hash": "sha256-ypTFCBmfwdvN4v+ts3dXhge0hDWUxa1/tUZhuddAf3s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonMode.js"
    },
    {
      "hash": "sha256-ntftpmcKbWcWot1dNbGv8Rk46C9ZShVnSjI4dhbWCX0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonMode.min.js"
    },
    {
      "hash": "sha256-oBNxsmfMjsFrTehhC/+0db8kDK32jOBq0XrXe3x2sSY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonWorker.js"
    },
    {
      "hash": "sha256-nc+ehSgxzF3YlRGOR9/Gy8EK7M7BZNfwAC792rynm7E=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonWorker.min.js"
    },
    {
      "hash": "sha256-068WSQli1welPGDpaw61kWDLiEKCg4e5KM7yQgQd61A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsMode.js"
    },
    {
      "hash": "sha256-edCxhuOUwBqBEmIg0I+ycWyuX/zbmYxaLf6KzgBL/Sk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsWorker.js"
    },
    {
      "hash": "sha256-vBrgmqeh87j27GsL6SpvgYfy/4jDFi33ZOOQRWqUNek=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsWorker.min.js"
    },
    {
      "hash": "sha256-QosjwcZvLgyvdY/ETfh3lsNDb9ssKpNA/OymyM/2xUs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.js"
    },
    {
      "hash": "sha256-XE7deisKztEgMFNjfcRwmPXWkLDZMIeoHK7W0bnmi5s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.min.js"
    },
    {
      "hash": "sha256-Ror3QOMwP8ju3jnvYpqX7VBSOF9xXoK9QrBwKN+EEW8=",
      "url": "_framework/BlazorMonaco.ef1a4jimsf.wasm"
    },
    {
      "hash": "sha256-ew4wIi+sqdK1zBjCJygTrm6Ur7YXlK/MeD0gtv808nQ=",
      "url": "_framework/DevTools.5knpi7ma8d.wasm"
    },
    {
      "hash": "sha256-kAlth8Twia/+u+Wi0jOKdeX39XtPnHPi0yrl4SrECsI=",
      "url": "_framework/Microsoft.AspNetCore.Components.0wvseqn6v5.wasm"
    },
    {
      "hash": "sha256-fyqnB2DYAO80AStwVkG2g+mFplGXI54QNWpUbk5VoiE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7apenvi18o.wasm"
    },
    {
      "hash": "sha256-pu76rHZnWXnD8OJbsfHeWNtvNYwvUMrsao8y79n+GXY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.mhi741p0i5.wasm"
    },
    {
      "hash": "sha256-+jEW7+PLBZuF7ZT+N+njb6GyuzvXPYElNkKhIixU4K4=",
      "url": "_framework/Microsoft.CSharp.29kynrf2qn.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-xJGsdCHz8ZnqW4DMzEAjFDJG+hPSdDKvwcYEdt/HJTE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.greu41qkcj.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-Pmq0WBMgjHXH2dCCDxV12WW8lvXrO4ctTn4jmRDjM4E=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6zla843dui.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-iOXJ6xMILdIdSWDD2fNHtnrXI0YtuWx4chp/bwgCVgc=",
      "url": "_framework/Microsoft.Extensions.Primitives.8omryeirak.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-3y1thJesChYq8FDb1x+q/EF3nLkv8b/y+cAa2pI93GQ=",
      "url": "_framework/NSQLFormatter.Standard.fk4fdnwiyr.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-a2ckpsen+0llJH3OMRaj9tHz53nwR0ifxAs3/fsIC6c=",
      "url": "_framework/System.Collections.Concurrent.3agg9uplfg.wasm"
    },
    {
      "hash": "sha256-owvtPf5Yml2Ev9oS6SdOsWYHWqQLe0t5ag+OUl/SFQ8=",
      "url": "_framework/System.Collections.Immutable.5uux6lm5jj.wasm"
    },
    {
      "hash": "sha256-vQw4IUaUlu+Ha95sDyURGsH/YRagDhTXQ+E8RtOEcLM=",
      "url": "_framework/System.Collections.NonGeneric.vt9yh7ueq7.wasm"
    },
    {
      "hash": "sha256-BhMowlB3S1OkpQ2vchLVroLdujtbUKKsYifKx3KKMyA=",
      "url": "_framework/System.Collections.Specialized.mlfgawrfb8.wasm"
    },
    {
      "hash": "sha256-Oa/61vJA2Iy07hr1bpmRG/VEOshq87VSllTTjUX1ISc=",
      "url": "_framework/System.Collections.bz565amopr.wasm"
    },
    {
      "hash": "sha256-1w043UqJg0IQaSJs6y+WriGUHJgrJI84cEqMaNHcNG8=",
      "url": "_framework/System.ComponentModel.Primitives.n08tslv9j4.wasm"
    },
    {
      "hash": "sha256-GDXJAU+L6aIfhc33HPFUPGNmwj4yv+EI7IFAWrD02v4=",
      "url": "_framework/System.ComponentModel.TypeConverter.8obo8f4wfu.wasm"
    },
    {
      "hash": "sha256-p9/EdyKA2VibTo7vh3Cq64rPrtt70HkWwGU+/JBNfhk=",
      "url": "_framework/System.ComponentModel.lxunkwpud9.wasm"
    },
    {
      "hash": "sha256-giaCxR5L7DAQY61fteNzl0Pn8Ea58CIYdPXLsDr+S80=",
      "url": "_framework/System.Console.i0jtp2i8qf.wasm"
    },
    {
      "hash": "sha256-mIWMvqE/+SPXzlydMU1aaJES4jFyN1PxUPrsoEOilgs=",
      "url": "_framework/System.Data.Common.snxgc45klz.wasm"
    },
    {
      "hash": "sha256-u2Fz1rnlnemBqO3kouLMsTJDsbZH0CD7bHyCiUKxQR0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.lkumuns4o8.wasm"
    },
    {
      "hash": "sha256-BkKPr6DiQleTg33Sad+xnRE11punpLElImPYgny/Msc=",
      "url": "_framework/System.Diagnostics.TraceSource.2aldlzzxjo.wasm"
    },
    {
      "hash": "sha256-gQjMxINvspnwX5incn+pT1YdyVFbCmatg8qwc+mlJT4=",
      "url": "_framework/System.Drawing.Primitives.7ivsdzph73.wasm"
    },
    {
      "hash": "sha256-T80AuWk5oNch/RPOfQ2j1jHHUNTHahti2HDKbJSBiYU=",
      "url": "_framework/System.Drawing.vs4w9hyl7j.wasm"
    },
    {
      "hash": "sha256-178PvlfqqHexwMa+sha7jkzLVkO2mDIOyznyHXwFjeI=",
      "url": "_framework/System.IO.Pipelines.xy0xpl5xng.wasm"
    },
    {
      "hash": "sha256-BXNLUSwzaj52SDIiGBJ7Gze1t1UxXY0iNKaM+M7OyLU=",
      "url": "_framework/System.Linq.Expressions.lgj2g1j773.wasm"
    },
    {
      "hash": "sha256-0gVO4Ihgeixqd4dM0YXZS9EN6p6gCGOOeGK1KtaVd2c=",
      "url": "_framework/System.Linq.yssc5tjsjw.wasm"
    },
    {
      "hash": "sha256-U6ZbSVacm7O8KwiF5HRUPz/sAsErExIcyDZk+rgWcUU=",
      "url": "_framework/System.Memory.xfrj41ayqo.wasm"
    },
    {
      "hash": "sha256-FCmIiK6fRdLi5y6jxS8kYfzqdRCG4t/yjZa4H5IPoq0=",
      "url": "_framework/System.Net.Http.0fxv4ipa8j.wasm"
    },
    {
      "hash": "sha256-jnSWuf5Fy5z+FXyicdP7crEW2t7uf5s4+qcEP273HHs=",
      "url": "_framework/System.Net.Primitives.el7k0yi1gl.wasm"
    },
    {
      "hash": "sha256-jVf8dHspTZR2/3BlPdmhcdN6Tq8mnSCxZcysLbRC6UQ=",
      "url": "_framework/System.ObjectModel.hzl9kj4ies.wasm"
    },
    {
      "hash": "sha256-cdpS+kFZhcTJR6/CL/hYbpXBWRpzGiN3xF1UfeLDr/s=",
      "url": "_framework/System.Private.CoreLib.7mjhc3jwfa.wasm"
    },
    {
      "hash": "sha256-ZDUg3IvbX5LPweahSbN/D8LCpnMQ1iHMzvB9uqG9jOk=",
      "url": "_framework/System.Private.Uri.wzpolv6nk9.wasm"
    },
    {
      "hash": "sha256-HpCeNsq8fP+vfFBBXiY5QXxnmPnadzoVxBoNiD7XT1s=",
      "url": "_framework/System.Private.Xml.Linq.6vosjcm03a.wasm"
    },
    {
      "hash": "sha256-W+8OYkDKNZNOhExkmvREGSTK7bPEk0m3xRi5uTOEn5c=",
      "url": "_framework/System.Private.Xml.nhy3may3zo.wasm"
    },
    {
      "hash": "sha256-tsBWyC0aPEg+L10DRvpwtYG/aYz68Z67Q3/JfhGhzGs=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.yt4xu3i1xs.wasm"
    },
    {
      "hash": "sha256-MT/UX43a2SUiCXniyy2mtN5qcFFdFjPgYh+QDnUGde4=",
      "url": "_framework/System.Reflection.Emit.Lightweight.10j0niatj8.wasm"
    },
    {
      "hash": "sha256-XQ2SHVDXhnmgf7Nr1a3vCNuOjTSR3Z5x0+brZySKzvE=",
      "url": "_framework/System.Reflection.Primitives.38o8i1plka.wasm"
    },
    {
      "hash": "sha256-bAbPaONHne7R1hItHoY8/SYWlDb84JZQ1cxd1Y+tJn0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0tgicm7vjk.wasm"
    },
    {
      "hash": "sha256-b6P7NzCJR04g8BS8t0FEzMMBaXojU9Zm4TWqrQcbT/w=",
      "url": "_framework/System.Runtime.InteropServices.vglz85lns8.wasm"
    },
    {
      "hash": "sha256-u1agIQbuvVw5XwwuoASR//TYYctxqNYOaEDahwRpQDM=",
      "url": "_framework/System.Runtime.Numerics.jqwsqyy2r0.wasm"
    },
    {
      "hash": "sha256-C1goi93J7Paa5scI5LX7Qwo/BCo8NdnMF50ufbO1xFg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.ls3n11vcp7.wasm"
    },
    {
      "hash": "sha256-DUuNnmUXnxUPRTcZZu2Zlpwi7nCKH9VL+Nr1rIttRK0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.douv2rdp0z.wasm"
    },
    {
      "hash": "sha256-5QWrP1qWyayZWS15ovNvGfSq2fxDll/mNI+CCyHDKzE=",
      "url": "_framework/System.Runtime.rk7nk4lovq.wasm"
    },
    {
      "hash": "sha256-glm7XI40reyMb40wNe+pO8hs+c+SvvkJzU0vWHuWj08=",
      "url": "_framework/System.Security.Cryptography.qx0z7k0men.wasm"
    },
    {
      "hash": "sha256-GKVw78ndgaxd6lZ5ifbDCunEJ0trxdhYProRgwAS+ws=",
      "url": "_framework/System.Text.Encoding.Extensions.0ihy4dw5y3.wasm"
    },
    {
      "hash": "sha256-ri5IusfFyIkUjHqd9C2j5KhwePbvKfCx401ZkHlLmPQ=",
      "url": "_framework/System.Text.Encodings.Web.yjewx7ynlb.wasm"
    },
    {
      "hash": "sha256-yaxUKlqUdX9mpEHgBRTdl+Jwv4sjJlcTiHBTOA8YEvA=",
      "url": "_framework/System.Text.Json.x6x3ykboas.wasm"
    },
    {
      "hash": "sha256-w57hvyzIoGKYuCh1FFkN5aKWXcb6Hk6gFSGpf9TtwG4=",
      "url": "_framework/System.Text.RegularExpressions.l2a1svs5lp.wasm"
    },
    {
      "hash": "sha256-E43HoGnshtwaJIT72ph2aRRA56T9sqqegRceVel67Ao=",
      "url": "_framework/System.Threading.vtuo7tegfe.wasm"
    },
    {
      "hash": "sha256-akuvaefMEZkY+xfX8AkcFNb1F9Qu3cRoTWvxlR6Vnw4=",
      "url": "_framework/System.Xml.Linq.yiwjknpdq4.wasm"
    },
    {
      "hash": "sha256-lvMvmrFillQG8kikOm28f6UwApF0pG2P6lzNesCr8PY=",
      "url": "_framework/System.Xml.ReaderWriter.qzxaxqcsmf.wasm"
    },
    {
      "hash": "sha256-GPeD3UBxKn4zjqfpQXbIVbPw8qkAZHhRuns+jqfIDKM=",
      "url": "_framework/System.Xml.XDocument.wuscq0843f.wasm"
    },
    {
      "hash": "sha256-YkFFFBkhWPJ9NX+mNSyGmlb6hmjtja4JNTnNi66JSGU=",
      "url": "_framework/System.icunsnzrqy.wasm"
    },
    {
      "hash": "sha256-ibY4H/AjJ938f7hH34KaqEr4eONXZjSATXmG3qDsUZ0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XoL4KXKUiNydxBQ0q7b/0gDsgsuq8oac0YMVUnGkfRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-8dMrTu9jQbP3wxC9egteDKHFcZpRmt0z0WElq8w+L44=",
      "url": "_framework/dotnet.native.33a0dzmw3n.wasm"
    },
    {
      "hash": "sha256-dLfkySliPNMWeaq+zTWklfVbFXPoRvAV7gtrpiL+4bs=",
      "url": "_framework/dotnet.native.83wgd5lk5q.js"
    },
    {
      "hash": "sha256-ilTXrnUF4HKbIAFVIYlRmX3ryKNZpGUObkWMF0n2Kcg=",
      "url": "_framework/dotnet.runtime.qrl1fuqt3c.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Ct142n5QK6Wm9/aPiH1SQ6boJ3kW2pxxsuaBLyQpugI=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-xkEAxlhUDYZhYn2ey6fYHbHt95IuRfIsueIDyyHYOxU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VOd0jE5WWzqpQjq4miUjONKHQxWt7cbBKJe0vNIMHnc=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-+3mLshcxmGlAzzqZUPvKOG4DYz6aRUl3Aecfm4fRMuo=",
      "url": "tailwindcss.3.4.16.js"
    }
  ]
};
